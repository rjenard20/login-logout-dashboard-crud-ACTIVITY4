﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace nard_login
{
    public partial class DashboardForm : Form
    {
        private readonly Action onLogout;
        private readonly Color primary = Color.FromArgb(65, 65, 65);
        private readonly Color page = Color.FromArgb(242, 243, 247);
        private readonly Color accent = Color.FromArgb(105, 82, 170);

        private Label lblWelcome = null!;
        private Label lblTotalValue = null!;
        private Label lblInStockValue = null!;
        private Label lblLowStockValue = null!;
        private Label lblOutStockValue = null!;
        private TextBox txtProductName = null!;
        private ComboBox cboCategory = null!;
        private TextBox txtDescription = null!;
        private TextBox txtUnitPrice = null!;
        private TextBox txtQuantity = null!;
        private TextBox txtReorderLevel = null!;
        private TextBox txtSearch = null!;
        private DataGridView gridProducts = null!;
        private int selectedProductId = 0;

        public DashboardForm(string fullName, Action logout)
        {
            onLogout = logout;
            Text = "NARD - Product Management";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1120, 790);
            MinimumSize = new Size(1000, 700);
            BackColor = page;
            Font = new Font("Segoe UI", 9F);
            BuildInterface(fullName);
            Load += DashboardForm_Load;
        }

        private void BuildInterface(string fullName)
        {
            Panel header = new Panel { Dock = DockStyle.Top, Height = 76, BackColor = primary };
            Controls.Add(header);

            Label brand = new Label
            {
                Text = "NARD  |  INVENTORY MANAGEMENT",
                AutoSize = true,
                Location = new Point(28, 22),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 17F, FontStyle.Bold)
            };
            header.Controls.Add(brand);

            Button btnLogout = MakeButton("LOG OUT", Color.FromArgb(235, 235, 235), primary, 105, 36);
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.Location = new Point(970, 20);
            btnLogout.Click += (s, e) => Close();
            header.Controls.Add(btnLogout);

            lblWelcome = new Label
            {
                Text = "Welcome, " + fullName + "!",
                AutoSize = true,
                Location = new Point(28, 94),
                Font = new Font("Segoe UI", 19F, FontStyle.Bold),
                ForeColor = primary
            };
            Controls.Add(lblWelcome);

            Label subtitle = new Label
            {
                Text = "Manage your inventory products",
                AutoSize = true,
                Location = new Point(31, 132),
                ForeColor = Color.Gray,
                Font = new Font("Segoe UI", 10F)
            };
            Controls.Add(subtitle);

            Panel stats = new Panel { Location = new Point(25, 165), Size = new Size(1050, 100), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            Controls.Add(stats);
            lblTotalValue = AddStatCard(stats, "TOTAL PRODUCTS", 0, Color.FromArgb(220, 226, 235));
            lblInStockValue = AddStatCard(stats, "IN STOCK", 1, Color.FromArgb(220, 235, 224));
            lblLowStockValue = AddStatCard(stats, "LOW STOCK", 2, Color.FromArgb(250, 235, 215));
            lblOutStockValue = AddStatCard(stats, "OUT OF STOCK", 3, Color.FromArgb(246, 222, 225));

            GroupBox editor = new GroupBox
            {
                Text = "  PRODUCT DETAILS  ",
                Location = new Point(25, 280),
                Size = new Size(1050, 205),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = primary
            };
            Controls.Add(editor);

            txtProductName = AddTextField(editor, "Product Name", 18, 30, 270, 30);
            cboCategory = new ComboBox
            {
                Location = new Point(310, 55),
                Size = new Size(270, 30),
                DropDownStyle = ComboBoxStyle.DropDown,
                Font = new Font("Segoe UI", 10F)
            };
            cboCategory.Items.AddRange(new object[] { "Food", "Beverages", "Electronics", "Clothing", "School Supplies", "Other" });
            editor.Controls.Add(cboCategory);
            AddFieldLabel(editor, "Category", 310, 30);

            txtUnitPrice = AddTextField(editor, "Unit Price", 605, 30, 180, 30);
            txtQuantity = AddTextField(editor, "Quantity", 18, 105, 170, 30);
            txtReorderLevel = AddTextField(editor, "Reorder Level", 210, 105, 170, 30);
            txtDescription = new TextBox
            {
                Location = new Point(405, 130),
                Size = new Size(380, 52),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 10F)
            };
            editor.Controls.Add(txtDescription);
            AddFieldLabel(editor, "Description", 405, 105);

            Button add = MakeButton("ADD PRODUCT", Color.FromArgb(72, 125, 90), Color.White, 125, 34);
            add.Location = new Point(850, 35);
            add.Click += AddProduct_Click;
            editor.Controls.Add(add);

            Button update = MakeButton("UPDATE", accent, Color.White, 125, 34);
            update.Location = new Point(850, 77);
            update.Click += UpdateProduct_Click;
            editor.Controls.Add(update);

            Button delete = MakeButton("DELETE", Color.FromArgb(174, 75, 82), Color.White, 125, 34);
            delete.Location = new Point(850, 119);
            delete.Click += DeleteProduct_Click;
            editor.Controls.Add(delete);

            Button clear = MakeButton("CLEAR", Color.FromArgb(225, 226, 232), primary, 125, 34);
            clear.Location = new Point(850, 161);
            clear.Click += (s, e) => ClearFields();
            editor.Controls.Add(clear);

            GroupBox list = new GroupBox
            {
                Text = "  PRODUCT LIST  ",
                Location = new Point(25, 500),
                Size = new Size(1050, 235),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = primary
            };
            Controls.Add(list);

            Label searchLabel = new Label { Text = "Search:", AutoSize = true, Location = new Point(625, 28), ForeColor = primary };
            list.Controls.Add(searchLabel);
            txtSearch = new TextBox { Location = new Point(685, 24), Size = new Size(230, 27), Font = new Font("Segoe UI", 10F), Anchor = AnchorStyles.Top | AnchorStyles.Right };
            txtSearch.TextChanged += (s, e) => LoadProducts();
            list.Controls.Add(txtSearch);

            Button refresh = MakeButton("REFRESH", Color.FromArgb(225, 226, 232), primary, 95, 28);
            refresh.Location = new Point(925, 22);
            refresh.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            refresh.Click += (s, e) => { LoadProducts(); LoadStatistics(); };
            list.Controls.Add(refresh);

            gridProducts = new DataGridView
            {
                Location = new Point(15, 62),
                Size = new Size(1018, 155),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                RowHeadersVisible = false,
                AutoGenerateColumns = true
            };
            gridProducts.CellClick += GridProducts_CellClick;
            gridProducts.EnableHeadersVisualStyles = false;
            gridProducts.ColumnHeadersDefaultCellStyle.BackColor = primary;
            gridProducts.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridProducts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            gridProducts.DefaultCellStyle.SelectionBackColor = Color.FromArgb(222, 215, 241);
            gridProducts.DefaultCellStyle.SelectionForeColor = primary;
            list.Controls.Add(gridProducts);

            FormClosed += (s, e) => onLogout();
        }

        private Label AddStatCard(Control parent, string title, int index, Color color)
        {
            int gap = 14;
            int width = (parent.Width - gap * 3) / 4;
            Panel card = new Panel
            {
                Location = new Point(index * (width + gap), 0),
                Size = new Size(width, 88),
                BackColor = color,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            parent.Controls.Add(card);
            Label heading = new Label
            {
                Text = title,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 34,
                ForeColor = primary,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };
            card.Controls.Add(heading);
            Label value = new Label
            {
                Text = "0",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = primary,
                Font = new Font("Segoe UI", 22F, FontStyle.Bold)
            };
            card.Controls.Add(value);
            value.BringToFront();
            return value;
        }

        private TextBox AddTextField(Control parent, string label, int x, int y, int width, int height)
        {
            AddFieldLabel(parent, label, x, y);
            TextBox box = new TextBox
            {
                Location = new Point(x, y + 25),
                Size = new Size(width, height),
                Font = new Font("Segoe UI", 10F),
                BorderStyle = BorderStyle.FixedSingle
            };
            parent.Controls.Add(box);
            return box;
        }

        private void AddFieldLabel(Control parent, string text, int x, int y)
        {
            parent.Controls.Add(new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = primary,
                Font = new Font("Segoe UI", 9F, FontStyle.Regular)
            });
        }

        private Button MakeButton(string text, Color back, Color fore, int width, int height)
        {
            Button button = new Button
            {
                Text = text,
                Size = new Size(width, height),
                BackColor = back,
                ForeColor = fore,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private void DashboardForm_Load(object? sender, EventArgs e)
        {
            try
            {
                DatabaseHelper.EnsureProductsTable();
                LoadProducts();
                LoadStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load inventory.\n\n" + ex.Message,
                    "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool TryReadFields(out string name, out string category, out string description,
            out decimal price, out int quantity, out int reorder)
        {
            name = txtProductName.Text.Trim();
            category = cboCategory.Text.Trim();
            description = txtDescription.Text.Trim();
            price = 0;
            quantity = 0;
            reorder = 0;

            if (name.Length == 0)
            {
                MessageBox.Show("Please enter the product name.");
                txtProductName.Focus();
                return false;
            }
            if (!decimal.TryParse(txtUnitPrice.Text.Trim(), out price) || price < 0)
            {
                MessageBox.Show("Enter a valid unit price (zero or higher).");
                txtUnitPrice.Focus();
                return false;
            }
            if (!int.TryParse(txtQuantity.Text.Trim(), out quantity) || quantity < 0)
            {
                MessageBox.Show("Enter a valid quantity (zero or higher).");
                txtQuantity.Focus();
                return false;
            }
            if (!int.TryParse(txtReorderLevel.Text.Trim(), out reorder) || reorder < 0)
            {
                MessageBox.Show("Enter a valid reorder level (zero or higher).");
                txtReorderLevel.Focus();
                return false;
            }
            return true;
        }

        private void AddProduct_Click(object? sender, EventArgs e)
        {
            if (!TryReadFields(out string name, out string category, out string description,
                out decimal price, out int quantity, out int reorder)) return;
            try
            {
                DatabaseHelper.AddProduct(name, category, description, price, quantity, reorder);
                MessageBox.Show("Product added successfully.", "Inventory",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                LoadProducts();
                LoadStatistics();
            }
            catch (Exception ex) { ShowDatabaseError(ex); }
        }

        private void UpdateProduct_Click(object? sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Please select a product from the list first.");
                return;
            }
            if (!TryReadFields(out string name, out string category, out string description,
                out decimal price, out int quantity, out int reorder)) return;
            try
            {
                DatabaseHelper.UpdateProduct(selectedProductId, name, category, description, price, quantity, reorder);
                MessageBox.Show("Product updated successfully.", "Inventory",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                LoadProducts();
                LoadStatistics();
            }
            catch (Exception ex) { ShowDatabaseError(ex); }
        }

        private void DeleteProduct_Click(object? sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Please select a product from the list first.");
                return;
            }
            if (MessageBox.Show("Are you sure you want to delete this product?", "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
            try
            {
                DatabaseHelper.DeleteProduct(selectedProductId);
                MessageBox.Show("Product deleted successfully.");
                ClearFields();
                LoadProducts();
                LoadStatistics();
            }
            catch (Exception ex) { ShowDatabaseError(ex); }
        }

        private void GridProducts_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow row = gridProducts.Rows[e.RowIndex];
            selectedProductId = Convert.ToInt32(row.Cells["ProductID"].Value);
            txtProductName.Text = Convert.ToString(row.Cells["ProductName"].Value) ?? "";
            cboCategory.Text = Convert.ToString(row.Cells["Category"].Value) ?? "";
            txtDescription.Text = Convert.ToString(row.Cells["Description"].Value) ?? "";
            txtUnitPrice.Text = Convert.ToDecimal(row.Cells["UnitPrice"].Value).ToString("0.00");
            txtQuantity.Text = Convert.ToString(row.Cells["Quantity"].Value) ?? "0";
            txtReorderLevel.Text = Convert.ToString(row.Cells["ReorderLevel"].Value) ?? "0";
        }

        private void LoadProducts()
        {
            if (gridProducts == null) return;
            DataTable products = DatabaseHelper.GetProducts(txtSearch?.Text ?? "");
            gridProducts.DataSource = products;
            if (gridProducts.Columns["ProductID"] != null)
                gridProducts.Columns["ProductID"].HeaderText = "ID";
            if (gridProducts.Columns["ProductName"] != null)
                gridProducts.Columns["ProductName"].HeaderText = "Product Name";
            if (gridProducts.Columns["UnitPrice"] != null)
                gridProducts.Columns["UnitPrice"].DefaultCellStyle.Format = "₱#,##0.00";
            if (gridProducts.Columns["ReorderLevel"] != null)
                gridProducts.Columns["ReorderLevel"].HeaderText = "Reorder Level";
        }

        private void LoadStatistics()
        {
            int[] counts = DatabaseHelper.GetProductCounts();
            lblTotalValue.Text = counts[0].ToString();
            lblInStockValue.Text = counts[1].ToString();
            lblLowStockValue.Text = counts[2].ToString();
            lblOutStockValue.Text = counts[3].ToString();
        }

        private void ClearFields()
        {
            selectedProductId = 0;
            txtProductName.Clear();
            cboCategory.Text = "";
            txtDescription.Clear();
            txtUnitPrice.Clear();
            txtQuantity.Clear();
            txtReorderLevel.Clear();
            gridProducts.ClearSelection();
            txtProductName.Focus();
        }

        private static void ShowDatabaseError(Exception ex)
        {
            MessageBox.Show("The operation could not be completed.\n\n" + ex.Message,
                "Inventory Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
