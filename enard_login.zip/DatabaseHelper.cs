﻿
using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace nard_login
{
    public static class DatabaseHelper
    {
        private static readonly string DatabasePath =
            FindDatabasePath();

        private static readonly string ConnectionString =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" +
            DatabasePath + ";Persist Security Info=False;";

        // DATABASE LOCATION
        private static string FindDatabasePath()
        {
            string projectPath = Path.GetFullPath(
                Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "..", "..", "..", "RamirezLogin.accdb"
                ));

            string outputPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "RamirezLogin.accdb"
            );

            if (File.Exists(projectPath))
                return projectPath;

            return outputPath;
        }

        // DATABASE CONNECTION
        private static OleDbConnection GetConnection()
        {
            if (!File.Exists(DatabasePath))
                throw new FileNotFoundException(
                    "Database not found: " + DatabasePath);

            return new OleDbConnection(ConnectionString);
        }

        // CREATE PRODUCTS TABLE IF NEEDED
        public static void EnsureProductsTable()
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                try
                {
                    using (OleDbCommand check =
                        new OleDbCommand(
                            "SELECT COUNT(*) FROM [Products]",
                            connection))
                    {
                        check.ExecuteScalar();
                    }
                }
                catch (OleDbException)
                {
                    string sql =
                        "CREATE TABLE [Products] (" +
                        "[ProductID] COUNTER PRIMARY KEY, " +
                        "[ProductName] TEXT(150), " +
                        "[Category] TEXT(100), " +
                        "[Description] MEMO, " +
                        "[UnitPrice] CURRENCY, " +
                        "[Quantity] LONG, " +
                        "[ReorderLevel] LONG)";

                    using (OleDbCommand create =
                        new OleDbCommand(sql, connection))
                    {
                        create.ExecuteNonQuery();
                    }
                }
            }
        }

        // READ PRODUCTS
        public static DataTable GetProducts(string search = "")
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "SELECT [ProductID], [ProductName], [Category], " +
                    "[Description], [UnitPrice], [Quantity], " +
                    "[ReorderLevel] FROM [Products]";

                using (OleDbCommand command =
                    new OleDbCommand())
                {
                    command.Connection = connection;

                    if (!string.IsNullOrWhiteSpace(search))
                    {
                        sql += " WHERE [ProductName] LIKE ? " +
                               "OR [Category] LIKE ?";

                        string keyword = "*" + search.Trim() + "*";

                        command.Parameters.Add(
                            "?", OleDbType.VarWChar, 150).Value = keyword;

                        command.Parameters.Add(
                            "?", OleDbType.VarWChar, 100).Value = keyword;
                    }

                    sql += " ORDER BY [ProductName]";
                    command.CommandText = sql;

                    DataTable table = new DataTable();

                    using (OleDbDataAdapter adapter =
                        new OleDbDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }

                    return table;
                }
            }
        }

        // INVENTORY STATISTICS
        public static int[] GetProductCounts()
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                int total = Convert.ToInt32(
                    new OleDbCommand(
                        "SELECT COUNT(*) FROM [Products]",
                        connection).ExecuteScalar());

                int inStock = Convert.ToInt32(
                    new OleDbCommand(
                        "SELECT COUNT(*) FROM [Products] " +
                        "WHERE [Quantity] > [ReorderLevel]",
                        connection).ExecuteScalar());

                int lowStock = Convert.ToInt32(
                    new OleDbCommand(
                        "SELECT COUNT(*) FROM [Products] " +
                        "WHERE [Quantity] > 0 AND " +
                        "[Quantity] <= [ReorderLevel]",
                        connection).ExecuteScalar());

                int outOfStock = Convert.ToInt32(
                    new OleDbCommand(
                        "SELECT COUNT(*) FROM [Products] " +
                        "WHERE [Quantity] = 0",
                        connection).ExecuteScalar());

                return new int[]
                {
                    total, inStock, lowStock, outOfStock
                };
            }
        }

        // ADD PRODUCT
        public static void AddProduct(
            string name,
            string category,
            string description,
            decimal unitPrice,
            int quantity,
            int reorderLevel)
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "INSERT INTO [Products] " +
                    "([ProductName], [Category], [Description], " +
                    "[UnitPrice], [Quantity], [ReorderLevel]) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

                using (OleDbCommand command =
                    new OleDbCommand(sql, connection))
                {
                    AddProductParameters(
                        command, name, category, description,
                        unitPrice, quantity, reorderLevel);

                    command.ExecuteNonQuery();
                }
            }
        }

        // UPDATE PRODUCT
        public static void UpdateProduct(
            int id,
            string name,
            string category,
            string description,
            decimal unitPrice,
            int quantity,
            int reorderLevel)
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "UPDATE [Products] SET " +
                    "[ProductName]=?, [Category]=?, " +
                    "[Description]=?, [UnitPrice]=?, " +
                    "[Quantity]=?, [ReorderLevel]=? " +
                    "WHERE [ProductID]=?";

                using (OleDbCommand command =
                    new OleDbCommand(sql, connection))
                {
                    AddProductParameters(
                        command, name, category, description,
                        unitPrice, quantity, reorderLevel);

                    command.Parameters.Add(
                        "?", OleDbType.Integer).Value = id;

                    if (command.ExecuteNonQuery() == 0)
                        throw new Exception("Product not found.");
                }
            }
        }

        // DELETE PRODUCT
        public static void DeleteProduct(int id)
        {
            EnsureProductsTable();

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string sql =
                    "DELETE FROM [Products] WHERE [ProductID]=?";

                using (OleDbCommand command =
                    new OleDbCommand(sql, connection))
                {
                    command.Parameters.Add(
                        "?", OleDbType.Integer).Value = id;

                    if (command.ExecuteNonQuery() == 0)
                        throw new Exception("Product not found.");
                }
            }
        }

        // PRODUCT PARAMETERS
        private static void AddProductParameters(
            OleDbCommand command,
            string name,
            string category,
            string description,
            decimal price,
            int quantity,
            int reorder)
        {
            command.Parameters.Add(
                "?", OleDbType.VarWChar, 150).Value = name;

            command.Parameters.Add(
                "?", OleDbType.VarWChar, 100).Value =
                string.IsNullOrWhiteSpace(category)
                    ? (object)DBNull.Value : category;

            command.Parameters.Add(
                "?", OleDbType.LongVarWChar).Value =
                string.IsNullOrWhiteSpace(description)
                    ? (object)DBNull.Value : description;

            command.Parameters.Add(
                "?", OleDbType.Currency).Value = price;

            command.Parameters.Add(
                "?", OleDbType.Integer).Value = quantity;

            command.Parameters.Add(
                "?", OleDbType.Integer).Value = reorder;
        }

        // PASSWORD HASHING FOR DATABASE
        private static string CreatePasswordHash(string password)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);

            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password,
                salt,
                100000,
                HashAlgorithmName.SHA256,
                32);

            return Convert.ToBase64String(salt) + "." +
                   Convert.ToBase64String(hash);
        }

        private static bool VerifyPassword(
            string password, string storedHash)
        {
            try
            {
                string[] parts = storedHash.Split('.');

                if (parts.Length != 2)
                    return false;

                byte[] salt = Convert.FromBase64String(parts[0]);
                byte[] originalHash =
                    Convert.FromBase64String(parts[1]);

                byte[] newHash = Rfc2898DeriveBytes.Pbkdf2(
                    password,
                    salt,
                    100000,
                    HashAlgorithmName.SHA256,
                    32);

                return CryptographicOperations.FixedTimeEquals(
                    originalHash, newHash);
            }
            catch
            {
                return false;
            }
        }

        // REGISTER USER
        public static bool RegisterUser(
            string fullName,
            string username,
            string password)
        {
            try
            {
                using (OleDbConnection connection = GetConnection())
                {
                    connection.Open();

                    using (OleDbCommand check =
                        new OleDbCommand(
                            "SELECT COUNT(*) FROM [Users] " +
                            "WHERE [Username]=?", connection))
                    {
                        check.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = username;

                        if (Convert.ToInt32(
                            check.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show(
                                "Username already exists!");

                            return false;
                        }
                    }

                    string sql =
                        "INSERT INTO [Users] " +
                        "([FullName], [Username], [PasswordHash]) " +
                        "VALUES (?, ?, ?)";

                    using (OleDbCommand command =
                        new OleDbCommand(sql, connection))
                    {
                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = fullName;

                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = username;

                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value =
                            CreatePasswordHash(password);

                        return command.ExecuteNonQuery() > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Registration Error: " + ex.Message);

                return false;
            }
        }

        // LOGIN USER
        public static bool LoginUser(
            string username,
            string password,
            out string fullName)
        {
            fullName = "";

            try
            {
                using (OleDbConnection connection = GetConnection())
                {
                    connection.Open();

                    string sql =
                        "SELECT [FullName], [PasswordHash] " +
                        "FROM [Users] WHERE [Username]=?";

                    using (OleDbCommand command =
                        new OleDbCommand(sql, connection))
                    {
                        command.Parameters.Add(
                            "?", OleDbType.VarWChar).Value = username;

                        using (OleDbDataReader reader =
                            command.ExecuteReader())
                        {
                            if (reader != null && reader.Read())
                            {
                                string storedName =
                                    reader["FullName"].ToString() ?? "";

                                string storedHash =
                                    reader["PasswordHash"].ToString() ?? "";

                                if (VerifyPassword(password, storedHash))
                                {
                                    fullName = storedName;
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Login Error: " + ex.Message);
            }

            return false;
        }
    }
}
