﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace nard_login
{
    public partial class RegistrationForm : Form
    {
        TextBox txtFullName = new TextBox();
        TextBox txtUsername = new TextBox();
        TextBox txtPassword = new TextBox();
        TextBox txtConfirmPassword = new TextBox();

        public RegistrationForm()
        {
            Text = "Registration";
            Size = new Size(420, 570);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(230, 230, 230);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Label title = new Label()
            {
                Text = "CREATE ACCOUNT",
                Font = new Font("Segoe UI", 19, FontStyle.Bold),
                ForeColor = Color.FromArgb(55, 55, 55),
                AutoSize = true,
                Location = new Point(75, 35)
            };
            Controls.Add(title);

            AddField("Full Name", txtFullName, 110);
            AddField("Username", txtUsername, 190);

            AddField("Password", txtPassword, 270);
            txtPassword.UseSystemPasswordChar = true;

            AddField("Confirm Password", txtConfirmPassword, 350);
            txtConfirmPassword.UseSystemPasswordChar = true;

            Button btnRegister = new Button()
            {
                Text = "REGISTER",
                Location = new Point(65, 435),
                Size = new Size(275, 42),
                BackColor = Color.FromArgb(65, 65, 65),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnRegister.Click += Register_Click;
            Controls.Add(btnRegister);

            Button btnBack = new Button()
            {
                Text = "BACK TO LOGIN",
                Location = new Point(65, 485),
                Size = new Size(275, 35),
                BackColor = Color.FromArgb(190, 190, 190),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnBack.Click += (s, e) => Close();
            Controls.Add(btnBack);
        }

        private void AddField(string label, TextBox textbox, int y)
        {
            Label lbl = new Label()
            {
                Text = label,
                Location = new Point(65, y),
                AutoSize = true,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            textbox.Location = new Point(65, y + 25);
            textbox.Size = new Size(275, 30);
            textbox.Font = new Font("Segoe UI", 11);

            Controls.Add(lbl);
            Controls.Add(textbox);
        }

        private void Register_Click(object? sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;

            if (fullName == "" || username == "" ||
                password == "" || confirmPassword == "")
            {
                MessageBox.Show("Please complete all fields.");
                return;
            }

            if (password.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters.");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            try
            {
                bool success = DatabaseHelper.RegisterUser(
                    fullName, username, password);

                if (success)
                {
                    MessageBox.Show("Registration successful!");

                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Username already exists.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Registration error: " + ex.Message);
            }
        }

        private void RegistrationForm_Load(object? sender, EventArgs e)
        {
            // Registration load event
        }
    }
}
